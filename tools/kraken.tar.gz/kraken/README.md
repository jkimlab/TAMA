Kraken taxonomic sequence classification system
===============================================

Please see the [Kraken webpage] or the [Kraken manual]
for information on installing and operating Kraken.
A local copy of the [Kraken manual] is also present here
in the `docs/` directory (`MANUAL.html` and `MANUAL.markdown`).

[Kraken webpage]:   http://ccb.jhu.edu/software/kraken/
[Kraken manual]:    http://ccb.jhu.edu/software/kraken/MANUAL.html
