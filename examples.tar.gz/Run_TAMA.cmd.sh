## Run TAMA
perl ./TAMA.pl -p 20 -o ./TAMAout --param ./params -t True

