## Creating custom database
perl ./src/Create_customDB.pl -ref ./examples/ref_list.example -names ./examples/names.dmp.gz -nodes ./examples/nodes.dmp.gz -o example_db
## Run TAMA
perl ./TAMA.pl -p 20 -o ./ExampleTest --param ./examples/params.example -t True

